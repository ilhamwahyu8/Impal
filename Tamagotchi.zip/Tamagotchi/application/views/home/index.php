<div class="container ">
    <br><br><br><br>
    <h1>Selamat datang <?php echo $_SESSION['Email']?></h1>
</div> 